import nltk

nltk.download('punkt')
nltk.download('stopwords')